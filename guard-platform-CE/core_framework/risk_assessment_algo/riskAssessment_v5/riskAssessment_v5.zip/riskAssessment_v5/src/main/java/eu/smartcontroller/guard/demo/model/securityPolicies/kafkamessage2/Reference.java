package eu.smartcontroller.guard.demo.model.securityPolicies.kafkamessage2;

public class Reference {
    public String title;
    public String url;
}
