package eu.smartcontroller.guard.demo.model.securityPolicies.kafkamessage2;

import java.util.ArrayList;

public class GuardApi {
    public int qod;
    public String status;
    public ArrayList<Result> results;
}
