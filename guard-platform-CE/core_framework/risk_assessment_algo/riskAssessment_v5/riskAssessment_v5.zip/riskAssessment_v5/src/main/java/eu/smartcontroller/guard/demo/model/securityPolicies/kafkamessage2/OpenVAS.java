package eu.smartcontroller.guard.demo.model.securityPolicies.kafkamessage2;

public class OpenVAS {
    public String report_file_prefix;
    public Report report;
}
