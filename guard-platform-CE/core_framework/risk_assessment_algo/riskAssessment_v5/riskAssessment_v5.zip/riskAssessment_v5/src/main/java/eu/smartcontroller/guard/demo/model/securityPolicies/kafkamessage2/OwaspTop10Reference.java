package eu.smartcontroller.guard.demo.model.securityPolicies.kafkamessage2;

public class OwaspTop10Reference {
    public String link;
    public String owasp_version;
    public int risk_id;
}
