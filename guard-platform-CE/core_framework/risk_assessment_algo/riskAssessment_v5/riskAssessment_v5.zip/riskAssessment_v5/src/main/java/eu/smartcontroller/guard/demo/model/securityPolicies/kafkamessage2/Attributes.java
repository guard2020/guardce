package eu.smartcontroller.guard.demo.model.securityPolicies.kafkamessage2;

public class Attributes {
    public String message;
}
